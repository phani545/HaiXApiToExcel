import "./App.css";
import JsonDataDisplay from "./sentiment";
import React from "react";

function App() {
  return (
    <div>
      <JsonDataDisplay></JsonDataDisplay>
    </div>
  );
}

export default App;
